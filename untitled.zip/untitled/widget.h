#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPixmap>
#include <QToolBar>
#include <QList> // 添加QList库支持

//class QToolBar;//tool bar on widget app

// IMAGE 图片类型
//qt:信号和槽机制 信号是信号 槽是进行操作的群体
//图片处理 rgba,rgb and alpha, r,g,b,a ,32 bit, r8bit
//opencv api can access rgb data


class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

//槽函数
public slots://qt规范将信号和槽写进slots和signals里面
    void openPic();  // 打开图片文件
    void reset();    // 重置到最初的图片
    void undo();     // 撤销上一步操作

private:
    void createToolBar();  // 创建工具栏
    void convertSketch();  // 灰度变换
    void transform();      // 应用转换效果
    void mosaic();         // 应用马赛克效果
    void blur();           // 应用模糊效果
    void saveCurrentState(); // 保存当前状态
    void dilateGray();
    void erodeGray();
    void dilate();
    void erode();

protected:
    void paintEvent(QPaintEvent *event) Q_DECL_OVERRIDE;//paintevent shows img, otherwise shows empty interface

private:
    QPixmap m_pix;  // 当前图片
    QList<QPixmap> history;  // 历史状态，用于撤销操作
    QToolBar* m_toolBar;  // 工具栏
    QString originalFilePath;  // 原始文件路径
};
#endif // WIDGET_H
