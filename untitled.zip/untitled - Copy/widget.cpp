#include "widget.h"
#include<QFileDialog>
#include<QAction>
#include<QToolBar> //toolbar
#include<QIcon>  //icon
#include<QString>//better string
#include<QPainter>
#include<QImage> //转变格式，pixmap显示比较好，qimage显示不好，但是可以显示像素图片，每个像素的rgb
#include<QDebug>

// #define KernelSize 5  // 选择一个小核，例如3x3
// #define MosaicSize 10

//const safer, not changeable,
//constexpr expression's calculation is done on defining, it is used for better performance
constexpr int KernelSize = 5; // 选择一个小核，例如3x3
constexpr int MosaicSize = 10;

#include<QColor>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    this->resize(800,500);
    this->createToolBar();
}

Widget::~Widget() {

}

void Widget::createToolBar() {
    this ->m_toolBar=new QToolBar(this);//分配内存

    //open image file
    QAction* openAct=new QAction(QIcon(":/icons/open image.png"), tr("Open"), this); //tr() : translate multilanguage support
    //QAction* openAct=new QAction(QIcon(":/icons/open image.png"),"打开图片");
    connect(openAct,&QAction::triggered,this,&Widget::openPic);
    this->m_toolBar->addAction(openAct);

    //reset
    QAction* resetAct=new QAction(QIcon(":/icons/recover.png"), tr("Reset"), this);
    connect(resetAct,&QAction::triggered,this,&Widget::reset);
    this->m_toolBar->addAction(resetAct);

    //undo
    QAction *undoAct = new QAction(QIcon(":/icons/goback.png"), tr("Undo"), this);
    connect(undoAct, &QAction::triggered, this, &Widget::undo);
    this->m_toolBar->addAction(undoAct);

    //gray
    QAction* grayAct=new QAction(QIcon(":/icons/convert.png"), tr("Gray"), this);
    connect(grayAct,&QAction::triggered,this,&Widget::convertSketch);//不要括号
    this->m_toolBar->addAction(grayAct);

    //transform, invert反转
    QAction* transformAct=new QAction(QIcon(":/icons/transform.png"), tr("Transform"), this);
    connect(transformAct,&QAction::triggered,this,&Widget::transform);
    this->m_toolBar->addAction(transformAct);


    //模糊
    QAction BlurAct(QIcon(":/icons/vague.png"), tr("Vague"), this);
    connect(&BlurAct,&QAction::triggered,this,&Widget::blur);
    this->m_toolBar->addAction(&BlurAct);

    //马赛克
    QAction* mosaicAct=new QAction(QIcon(":/icons/Mosaic.png"), tr("Mosaic"), this);
    connect(mosaicAct,&QAction::triggered,this,&Widget::mosaic);
    this->m_toolBar->addAction(mosaicAct);

    //水墨
    QAction* roleAct=new QAction(QIcon(":/icons/role.png"), tr("Convert"), this);
    this->m_toolBar->addAction(roleAct);
}

void Widget::openPic() {
    QString filePath=QFileDialog::getOpenFileName(this, "OpenImage", "./","image(*.jpg *.png *.bmp *.webp)");//no comma
    // originalFilePath=filePath;
    // this->m_pix=QPixmap(filePath);
    // this->resize(this->m_pix.size());//窗口根据图片大小改变

    if (!filePath.isEmpty()) {
        originalFilePath = filePath;
        this->m_pix = QPixmap(filePath);
        history.clear(); // 清空历史记录
        this->resize(this->m_pix.size());//窗口根据图片大小改变
        update(); // 更新界面
    }
}

void Widget::reset() {
    this->m_pix=QPixmap(originalFilePath);
    this->resize(this->m_pix.size());//窗口根据图片大小改变
    update();
}

void Widget::undo() {
    if (!history.isEmpty()) {
        this->m_pix = history.takeLast();
        this->resize(m_pix.size());  // 调整大小以匹配历史状态的尺寸
        update();  // 重绘窗口
    }
}

void Widget::convertSketch() { //gray
    saveCurrentState();
    QImage image = this->m_pix.toImage();
    QImage convertedImage = image.convertToFormat(QImage::Format_ARGB32);  // 使用返回的新图像对象
    for (int i = 0; i < convertedImage.width(); ++i) {
        for (int j = 0; j < convertedImage.height(); ++j) {
            QRgb pixel = convertedImage.pixel(i, j);
            int gray = qGray(pixel);  // 假设qGray是一个函数，返回灰度值
            convertedImage.setPixel(i, j, qRgb(gray, gray, gray));  // 在新图像上设置像素
        }
    }
    // 更新 QPixmap
    this->m_pix = QPixmap::fromImage(convertedImage);
    this->update();  // 更新 Widget 以反映新图像
}

void Widget::transform()
{
    saveCurrentState();
    QImage image = this->m_pix.toImage();
    QImage convertedImage = image.convertToFormat(QImage::Format_ARGB32);  // 使用返回的新图像对象
    for (int i = 0; i < convertedImage.width(); ++i) {
        for (int j = 0; j < convertedImage.height(); ++j) {
            QColor pixel = convertedImage.pixelColor(i, j);

            int r=pixel.red();
            int g=pixel.green();
            int b=pixel.blue();

            QColor newColor((255-r),(255-g),(255-b));
            convertedImage.setPixelColor(i, j, newColor);  // 在新图像上设置像素
        }
    }
    // 更新 QPixmap
    this->m_pix = QPixmap::fromImage(convertedImage);
    this->update();  // 更新 Widget 以反映新图像
}

void Widget::blur() { //mean blur           blur is for images, but vague is for defination.
    saveCurrentState();
    QImage image = this->m_pix.toImage();
    QImage blurredImage = image.copy();

    //int kernelSize = 3;  // 选择一个小核，例如3x3
    int edge = KernelSize / 2;

    // 循环遍历每个像素，忽略边缘以避免越界
    for (int x = edge; x < image.width() - edge; ++x) {
        for (int y = edge; y < image.height() - edge; ++y) {
            int sumR = 0, sumG = 0, sumB = 0;
            int count = 0;

            // 对每个像素应用3x3均值核
            for (int i = -edge; i <= edge; ++i) {
                for (int j = -edge; j <= edge; ++j) {
                    QColor color = image.pixelColor(x + i, y + j);
                    sumR += color.red();
                    sumG += color.green();
                    sumB += color.blue();
                    count++;
                }
            }

            QColor newColor(sumR / count, sumG / count, sumB / count);
            blurredImage.setPixelColor(x, y, newColor);
        }
    }

    // 更新 QPixmap 和 Widget
    this->m_pix = QPixmap::fromImage(blurredImage);
    this->update();  // 确保 Widget 重绘以反映更新
}

void Widget::mosaic()
{
    saveCurrentState();
    QImage image = this->m_pix.toImage();
    // QImage convertedImage = image.convertToFormat(QImage::Format_ARGB32);  // 使用返回的新图像对象

    // //constrains
    // int w=image.width()%MosaicSize;
    // int h=image.height()%MosaicSize;

    // for (int i = 0; i < convertedImage.width()-w; i+=MosaicSize)
    // {
    //     for (int j = 0; j < convertedImage.height()-h; j+=MosaicSize)
    //     {
    //         int r=0,g=0,b=0;
    //         for(int k=i;k<i+MosaicSize;++k)
    //         {
    //             for(int e = j;e<j+MosaicSize;++e)
    //             {
    //                 QColor c=image.pixelColor(k,e);
    //                 r+=c.red();
    //                 g+=c.green();
    //                 b+=c.blue();
    //             }
    //         }
    //         QColor newColor(r/(MosaicSize*MosaicSize),g/(MosaicSize*MosaicSize),b/(MosaicSize*MosaicSize));
    //         for(int k=i;k<i+MosaicSize;++k)
    //         {
    //             for(int e = j;e<j+MosaicSize;++e)
    //             {
    //                 image.setPixelColor(k,e,newColor);// 在新图像上设置像素
    //             }
    //         }
    //     }
    // }

    // // 更新 QPixmap
    // this->m_pix = QPixmap::fromImage(convertedImage);
    // this->update();  // 更新 Widget 以反映新图像


    // 使用原始图像的尺寸进行循环
    for (int i = 0; i < image.width(); i+=MosaicSize) {
        for (int j = 0; j < image.height(); j+=MosaicSize) {
            int r=0, g=0, b=0;
            int count = 0; // 计算实际处理的像素数量

            // 确保不会越界
            for(int k = i; k < std::min(i+MosaicSize, image.width()); ++k) {
                for(int e = j; e < std::min(j+MosaicSize, image.height()); ++e) {
                    QColor c = image.pixelColor(k, e);
                    r += c.red();
                    g += c.green();
                    b += c.blue();
                    count++;
                }
            }

            QColor newColor(r/count, g/count, b/count);

            for(int k = i; k < std::min(i+MosaicSize, image.width()); ++k) {
                for(int e = j; e < std::min(j+MosaicSize, image.height()); ++e) {
                    image.setPixelColor(k, e, newColor);
                }
            }
        }
    }

    // 更新 QPixmap 和 Widget
    this->m_pix = QPixmap::fromImage(image);
    this->update(); // 确保 Widget 重绘以反映更新
}

void Widget::paintEvent(QPaintEvent *event){
    QPainter p(this);
    p.drawPixmap(0,0,this->m_pix.width(),this->m_pix.height(),this->m_pix);
    QWidget::paintEvent(event);
}

void Widget::saveCurrentState() {
    if (!m_pix.isNull()) {
        history.push_back(m_pix);
    }
}


//other versions

// void Widget::convertSketch() { //gray
//     // QImage image=this->m_pix.toImage();
//     // Qimage.convertToFormat(QImage::Format_ARGB32);//convert format to rgvb

//     // for(int i=0;i<image.width();++i)
//     // {
//     //     for(int j=0;j<image.height();++j)
//     //     {
//     //         QRgb pixel=image.pixel(i,j);
//     //         int gray=qGray(pixel);

//     //         image.setPixel(i,j,qRgb(gray,gray,gray));//replace
//     //     }
//     // }
//     // //update
//     // this->m_pix=QPixmap::fromImage(image);
//     // this->update();
// }

//TODO last editted

//TODO QGraphicsBlurEffect
//TODO 高斯滤波

//TODO 水墨画
