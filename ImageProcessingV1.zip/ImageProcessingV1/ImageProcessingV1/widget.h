#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPixmap>
#include <QToolBar>
#include <QList>
#include <QFuture>
#include <QVBoxLayout>
#include <QtConcurrent>
#include <functional>

// Widget类，继承自QWidget // Widget class, inherited from QWidget
class Widget : public QWidget
{
    Q_OBJECT

public:
    // 构造函数，接受一个父窗口指针参数 // Constructor, takes a parent widget pointer as a parameter
    Widget(QWidget *parent = nullptr);
    ~Widget();

public slots:
    // 打开图片的槽函数 // Slot function to open an image
    void openPic();
    // 重置图片的槽函数 // Slot function to reset the image
    void reset();
    // 撤销操作的槽函数 // Slot function to undo the last operation
    void undo();

private:
    // 创建工具栏的函数 // Function to create the toolbar
    void createToolBar();
    // 将图片转换为灰度图的函数 // Function to convert the image to grayscale
    void convertSketch();
    // 反转图片颜色的函数 // Function to invert the image colors
    void transform();
    // 对图片进行马赛克处理的函数 // Function to apply mosaic effect to the image
    void mosaic();
    // 对图片进行均值模糊处理的函数 // Function to apply mean blur effect to the image
    void blur();
    // 对灰度图进行膨胀处理的函数 // Function to apply dilation to a grayscale image
    void dilateGray();
    // 对灰度图进行腐蚀处理的函数 // Function to apply erosion to a grayscale image
    void erodeGray();
    // 对彩色图进行膨胀处理的函数 // Function to apply dilation to a color image
    void dilate();
    // 对彩色图进行腐蚀处理的函数 // Function to apply erosion to a color image
    void erode();
    // 保存当前图片状态的函数，用于撤销操作 // Function to save the current state of the image for undo functionality
    void saveCurrentState();
    // 应用图片效果的函数，接受一个图片和一个效果函数作为参数 // Function to apply an effect to the image, takes an image and an effect function as parameters
    void applyImageEffect(const QImage &image, std::function<QImage(const QImage&)> effectFunc);

protected:
    // 绘图事件的处理函数，用于自定义窗口绘制 // Paint event handler, used for custom window drawing
    void paintEvent(QPaintEvent *event) Q_DECL_OVERRIDE;

private:
    QPixmap m_pix;  // 当前显示的图片 // Current displayed image
    QPixmap original_pix;  // 原始图片 // Original image
    QList<QPixmap> history;  // 图片历史记录列表 // List of image history for undo functionality
    QToolBar* m_toolBar;  // 工具栏 // Toolbar
    QString originalFilePath;  // 原始图片文件路径 // Original image file path
    QVBoxLayout* layout;  // 窗口布局 // Layout for the window
    QWidget* toolBarContainer;  // 工具栏容器 // Toolbar container
};

#endif // WIDGET_H
