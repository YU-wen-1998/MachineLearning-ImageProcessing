#include "widget.h"
#include<QFileDialog>
#include<QAction>
#include<QToolBar> //toolbar
#include<QIcon>  //icon
#include<QString>//better string
#include<QPainter>
#include<QImage> //转变格式，pixmap显示比较好，qimage显示不好，但是可以显示像素图片，每个像素的rgb
#include<QDebug>
#include <QtGlobal>

// #define KernelSize 5  // 选择一个小核，例如3x3
// #define MosaicSize 10

//const safer, not changeable,
//constexpr expression's calculation is done on defining, it is used for better performance
constexpr int KernelSize = 5; // 选择一个小核，例如3x3，3*3太小了，几乎没有区别，改为5*5
constexpr int MosaicSize = 10;

#include<QColor>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    this->resize(800, 500);

    layout = new QVBoxLayout(this);  // 初始化 QVBoxLayout
    this->setLayout(layout);

    toolBarContainer = new QWidget(this);  // 初始化工具栏容器
    toolBarContainer->setFixedHeight(90);  // 设置工具栏容器高度

    this->createToolBar();
}

Widget::~Widget() {

}

void Widget::createToolBar() {
    m_toolBar = new QToolBar(toolBarContainer); // 分配内存
    m_toolBar->setIconSize(QSize(39, 39)); // 设置图标大小，如果需要更改图标大小
    m_toolBar->setToolButtonStyle(Qt::ToolButtonTextUnderIcon); // 设置按钮样式，图标在上，文字在下

    // 调整样式以更改图标位置
    // QString styleSheet = "QToolBar { spacing: 5px; }" // 设置工具栏的内部间距
    //                     "QToolButton { background-color:#cccccc; padding-top: 10px; }"; // 调整图标的顶部填充

    // 调整样式以为 QToolButton 设置背景色并去除空隙
    QString styleSheet = "QToolBar {background-color: #cccccc}"
        "QToolButton { background-color: #dddddd; padding: 0px; margin: 0px; border: none; width: 65px; }";  // 设置固定宽度


    m_toolBar->setStyleSheet(styleSheet); // 应用样式表

    // open image file
    QAction* openAct = new QAction(QIcon(":/icons/open image.png"), tr("Open"), this); // tr() : translate multilanguage support
    connect(openAct, &QAction::triggered, this, &Widget::openPic);
    m_toolBar->addAction(openAct);

    // reset
    QAction* resetAct = new QAction(QIcon(":/icons/recover.png"), tr("Reset"), this);
    connect(resetAct, &QAction::triggered, this, &Widget::reset);
    m_toolBar->addAction(resetAct);

    // undo
    QAction* undoAct = new QAction(QIcon(":/icons/goback.png"), tr("Undo"), this);
    connect(undoAct, &QAction::triggered, this, &Widget::undo);
    m_toolBar->addAction(undoAct);

    // gray
    QAction* grayAct = new QAction(QIcon(":/icons/convert.png"), tr("Gray"), this);
    connect(grayAct, &QAction::triggered, this, &Widget::convertSketch);
    m_toolBar->addAction(grayAct);

    // transform, invert反转
    QAction* transformAct = new QAction(QIcon(":/icons/transform.png"), tr("Transform"), this);
    connect(transformAct, &QAction::triggered, this, &Widget::transform);
    m_toolBar->addAction(transformAct);

    // 模糊
    QAction* blurAct = new QAction(QIcon(":/icons/vague.png"), tr("Vague"), this);
    connect(blurAct, &QAction::triggered, this, &Widget::blur);
    m_toolBar->addAction(blurAct);

    // 马赛克
    QAction* mosaicAct = new QAction(QIcon(":/icons/Mosaic.png"), tr("Mosaic"), this);
    connect(mosaicAct, &QAction::triggered, this, &Widget::mosaic);
    m_toolBar->addAction(mosaicAct);

    // 水墨
    QAction* roleAct = new QAction(QIcon(":/icons/role.png"), tr("Convert"), this);
    m_toolBar->addAction(roleAct);

    // 膨胀和腐蚀
    QAction* dilateGrayAct = new QAction(QIcon(":/icons/dilateGray.png"), tr("DilateGray"), this);
    connect(dilateGrayAct, &QAction::triggered, this, &Widget::dilateGray);
    m_toolBar->addAction(dilateGrayAct);

    QAction* erodeGrayAct = new QAction(QIcon(":/icons/erodeGray.png"), tr("ErodeGray"), this);
    connect(erodeGrayAct, &QAction::triggered, this, &Widget::erodeGray);
    m_toolBar->addAction(erodeGrayAct);

    QAction* dilateAct = new QAction(QIcon(":/icons/dilate.png"), tr("Dilate"), this);
    connect(dilateAct, &QAction::triggered, this, &Widget::dilate);
    m_toolBar->addAction(dilateAct);

    QAction* erodeAct = new QAction(QIcon(":/icons/erode.png"), tr("Erode"), this);
    connect(erodeAct, &QAction::triggered, this, &Widget::erode);
    m_toolBar->addAction(erodeAct);

    QVBoxLayout *toolBarLayout = new QVBoxLayout(toolBarContainer);
    toolBarLayout->addWidget(m_toolBar);
    toolBarContainer->setLayout(toolBarLayout);

    layout->addWidget(toolBarContainer);  // 将工具栏容器添加到布局中
    layout->setAlignment(toolBarContainer, Qt::AlignTop);  // 将工具栏置于顶部
}

void Widget::openPic() {
    QString filePath=QFileDialog::getOpenFileName(this, "OpenImage", "./","image(*.jpg *.png *.bmp *.webp)");//no comma
    // originalFilePath=filePath;
    // this->m_pix=QPixmap(filePath);
    // this->resize(this->m_pix.size());//窗口根据图片大小改变

    if (!filePath.isEmpty()) {
        originalFilePath = filePath;
        this->m_pix = QPixmap(filePath);
        original_pix = QPixmap(filePath);  // 保存原始图片
        history.clear(); // 清空历史记录
        this->resize(this->m_pix.size() * 2); // 增加窗口宽度以显示两张图片
        update(); // 更新界面
    }
}

void Widget::reset() {
    this->m_pix=QPixmap(originalFilePath);
    this->resize(this->m_pix.size() * 2); // 增加窗口宽度以显示两张图片
    update();
}

void Widget::undo() {
    if (!history.isEmpty()) {
        this->m_pix = history.takeLast();
        this->resize(m_pix.size() * 2);  // 增加窗口宽度以显示两张图片
        update();  // 重绘窗口
    }
}

void Widget::convertSketch() { //gray
    saveCurrentState();
    applyImageEffect(m_pix.toImage(), [](const QImage &image) {
        QImage convertedImage = image.convertToFormat(QImage::Format_ARGB32);  // 使用返回的新图像对象
        for (int i = 0; i < convertedImage.width(); ++i) {
            for (int j = 0; j < convertedImage.height(); ++j) {
                QRgb pixel = convertedImage.pixel(i, j);
                int gray = qGray(pixel);  // 假设qGray是一个函数，返回灰度值
                convertedImage.setPixel(i, j, qRgb(gray, gray, gray));  // 在新图像上设置像素
            }
        }
        return convertedImage;
    });
}

void Widget::transform() {
    saveCurrentState();
    applyImageEffect(m_pix.toImage(), [](const QImage &image) {
        QImage convertedImage = image.convertToFormat(QImage::Format_ARGB32);  // 使用返回的新图像对象
        for (int i = 0; i < convertedImage.width(); ++i) {
            for (int j = 0; j < convertedImage.height(); ++j) {
                QColor pixel = convertedImage.pixelColor(i, j);

                int r=pixel.red();
                int g=pixel.green();
                int b=pixel.blue();

                QColor newColor((255-r),(255-g),(255-b));
                convertedImage.setPixelColor(i, j, newColor);  // 在新图像上设置像素
            }
        }
        return convertedImage;
    });
}

void Widget::blur() { //mean blur           blur is for images, but vague is for defination.
    saveCurrentState();
    applyImageEffect(m_pix.toImage(), [](const QImage &image) {
        QImage blurredImage = image.copy();
        int edge = KernelSize / 2;

        for (int x = edge; x < image.width() - edge; ++x) {
            for (int y = edge; y < image.height() - edge; ++y) {
                int sumR = 0, sumG = 0, sumB = 0;
                int count = 0;

                for (int i = -edge; i <= edge; ++i) {
                    for (int j = -edge; j <= edge; ++j) {
                        QColor color = image.pixelColor(x + i, y + j);
                        sumR += color.red();
                        sumG += color.green();
                        sumB += color.blue();
                        count++;
                    }
                }

                QColor newColor(sumR / count, sumG / count, sumB / count);
                blurredImage.setPixelColor(x, y, newColor);
            }
        }
        return blurredImage;
    });
}

void Widget::mosaic() {
    saveCurrentState();
    applyImageEffect(m_pix.toImage(), [](const QImage &image) {
        QImage outputImage = image.copy();
        for (int i = 0; i < image.width(); i+=MosaicSize) {
            for (int j = 0; j < image.height(); j+=MosaicSize) {
                int r=0, g=0, b=0;
                int count = 0; // 计算实际处理的像素数量

                for(int k = i; k < std::min(i+MosaicSize, image.width()); ++k) {
                    for(int e = j; e < std::min(j+MosaicSize, image.height()); ++e) {
                        QColor c = image.pixelColor(k, e);
                        r += c.red();
                        g += c.green();
                        b += c.blue();
                        count++;
                    }
                }

                QColor newColor(r/count, g/count, b/count);

                for(int k = i; k < std::min(i+MosaicSize, image.width()); ++k) {
                    for(int e = j; e < std::min(j+MosaicSize, image.height()); ++e) {
                        outputImage.setPixelColor(k, e, newColor);
                    }
                }
            }
        }
        return outputImage;
    });
}

void Widget::dilateGray() {
    saveCurrentState();
    applyImageEffect(m_pix.toImage(), [](const QImage &image) {
        QImage outputImage = image.copy();
        for (int y = 1; y < image.height() - 1; y++) {
            for (int x = 1; x < image.width() - 1; x++) {
                uchar maxPixel = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        uchar pixel = image.pixelColor(x + dx, y + dy).red();
                        maxPixel = std::max(maxPixel, pixel);
                    }
                }
                outputImage.setPixelColor(x, y, QColor(maxPixel, maxPixel, maxPixel));
            }
        }
        return outputImage;
    });
}

void Widget::erodeGray() {
    saveCurrentState();
    applyImageEffect(m_pix.toImage(), [](const QImage &image) {
        QImage outputImage = image.copy();
        for (int y = 1; y < image.height() - 1; y++) {
            for (int x = 1; x < image.width() - 1; x++) {
                uchar minPixel = 255;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        uchar pixel = image.pixelColor(x + dx, y + dy).red();
                        minPixel = std::min(minPixel, pixel);
                    }
                }
                outputImage.setPixelColor(x, y, QColor(minPixel, minPixel, minPixel));
            }
        }
        return outputImage;
    });
}

void Widget::dilate() {
    saveCurrentState();
    applyImageEffect(m_pix.toImage(), [](const QImage &image) {
        QImage outputImage = image.copy();
        for (int y = 1; y < image.height() - 1; y++) {
            for (int x = 1; x < image.width() - 1; x++) {
                int maxRed = 0, maxGreen = 0, maxBlue = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        QColor color = image.pixelColor(x + dx, y + dy);
                        maxRed = std::max(maxRed, color.red());
                        maxGreen = std::max(maxGreen, color.green());
                        maxBlue = std::max(maxBlue, color.blue());
                    }
                }
                outputImage.setPixelColor(x, y, QColor(maxRed, maxGreen, maxBlue));
            }
        }
        return outputImage;
    });
}

void Widget::erode() {
    saveCurrentState();
    applyImageEffect(m_pix.toImage(), [](const QImage &image) {
        QImage outputImage = image.copy();
        for (int y = 1; y < image.height() - 1; y++) {
            for (int x = 1; x < image.width() - 1; x++) {
                int minRed = 255, minGreen = 255, minBlue = 255;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        QColor color = image.pixelColor(x + dx, y + dy);
                        minRed = std::min(minRed, color.red());
                        minGreen = std::min(minGreen, color.green());
                        minBlue = std::min(minBlue, color.blue());
                    }
                }
                outputImage.setPixelColor(x, y, QColor(minRed, minGreen, minBlue));
            }
        }
        return outputImage;
    });
}

void Widget::paintEvent(QPaintEvent *event) {
    QPainter p(this);
    int yOffset = toolBarContainer->height();  // 计算工具栏容器的高度偏移
    int imageSpacing = 10;  // 两张图片之间的间隔

    // 绘制原始图片
    p.drawPixmap(0, yOffset, original_pix.width(), original_pix.height(), original_pix);

    // 绘制处理后的图片，位置右移 original_pix.width() + imageSpacing
    p.drawPixmap(original_pix.width() + imageSpacing, yOffset, m_pix.width(), m_pix.height(), m_pix);

    QWidget::paintEvent(event);
}

void Widget::saveCurrentState() {
    if (!m_pix.isNull()) {
        history.push_back(m_pix);
    }
}

void Widget::applyImageEffect(const QImage &image, std::function<QImage(const QImage&)> effectFunc) {
    QFuture<void> future = QtConcurrent::run([this, image, effectFunc]() {
        QImage result = effectFunc(image);
        QMetaObject::invokeMethod(this, [this, result]() {
                m_pix = QPixmap::fromImage(result);
                update();
            }, Qt::QueuedConnection);
    });
}
